package com.cibertec.enums;

public enum OrderStatus {
	
	PENDIENTE,
	
    PROCESANDO,
    
    ENVIADO,
    
    ENTREGADO,
    
    CANCELADO 
}
