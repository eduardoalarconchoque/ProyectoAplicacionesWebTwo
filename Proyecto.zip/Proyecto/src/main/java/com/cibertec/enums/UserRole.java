package com.cibertec.enums;

public enum UserRole {
	
	CUSTOMER, 
	ADMINISTRATOR;
	
}
