package com.cibertec.enums;

public enum PaymentStatus {
	
	COMPLETADO,
	
    PENDIENTE,
    
    FALLIDO,
    
     PAGADO
}
