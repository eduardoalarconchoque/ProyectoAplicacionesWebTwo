package com.cibertec.dto;

import lombok.Data;

@Data
public class CategoryDto {

	private Long id;
	
	private String nombre;
	
}
