package com.cibertec.dto;

import lombok.Data;

@Data
public class UserDto {

	
	private  Long id ; 
	
	private String email ; 
	
	private String nombre ; 
	
	private String password; 
	
}
